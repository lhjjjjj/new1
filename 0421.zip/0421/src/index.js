
import React,{fragment, Component} from 'react';
import ReactDOM from 'react-dom'
import App from './App'
import './App.css';

// class App extends Component {

//     constructor(props){
//         super(props);
//         console.log("constructor")
//     }

//     static getivedStateFromProps(nextProps, PrevState){
//         console.log("getivedStateFromProps")
//         return null;
//     }

//     componentDidMount(){
//         console.log("componentDidMount")
//     }

//     shouldComponentUpdate(nextProps, nextState){
//         console.log("shouldComponentUpdate")
//         if(nextState.number>10){
//             return false;
//         }
//         return true;
//     }

//     getSnapshotBeforeUpdate(PrevState, PrevProps){
//         console.log("getSnapshotBeforeUpdate")
//         const snaphot={}
//         return snaphot
//     }

//     componentDidUpdate(prevProps, PrevState, snaphot){
//         console.log("componentDidUpdate")
//     }


//     componentWillUnmount(){
//         console.log("componentWillUnmount")
//     }

//     state={
//         number:7
//     }

//     onClick = ()=>{
//         this.setState({
//             number: this.state.number+1,
//         })
//     }

//     render(){
//         const {number} = this.state;
//         return <h1 onClick={this.onClick}>{number}</h1>
//         }
// }

ReactDOM.render(<App/>, document.getElementById('root'));
