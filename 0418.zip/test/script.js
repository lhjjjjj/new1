var scroll = new SmoothScroll('a[href*="#"]');

$('button.mobile, ul li a').click(function () {
    $('nav').toggleClass('mobile-nav');
});