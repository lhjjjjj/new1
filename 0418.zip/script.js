var scroll = new SmoothScroll('a[href*="#"]');

//$('button.mobile, ul li a').click(function () {
//    $('nav').toggleClass('mobile-nav');
//});

//function myFunction() {
//  document.getElementById("drop").classList.toggle("show");
//}
//
//window.onclick = function(e) {
//  if (!e.target.matches('.mobile')) {
//  var myDropdown = document.getElementById("drop");
//    if (myDropdown.classList.contains('show')) {
//      myDropdown.classList.remove('show');
//    }
//  }
//}

$(document).ready(function(){
        // menu 클래스 바로 하위에 있는 a 태그를 클릭했을때
        $(".mobile").click(function(){
            var submenu = $(this).next("ul");
 
            // submenu 가 화면상에 보일때는 위로 보드랍게 접고 아니면 아래로 보드랍게 펼치기
            if( submenu.is(":visible") ){
                submenu.slideUp();
            }else{
                submenu.slideDown();
            }
        });
    });

$(document).ready(function() { var placeholderTarget = $('.textbox input[type="text"], .textbox input[type="password"]'); 
                              
//포커스시 
placeholderTarget.on('focus', function(){
    $(this).siblings('label').fadeOut('fast'); }); 
//포커스아웃시 
placeholderTarget.on('focusout', function(){
    if($(this).val() == ''){
        $(this).siblings('label').fadeIn('fast'); 
    }
    });
 });
